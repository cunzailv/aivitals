"""命令行入口。"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

from . import claims as claims_mod, detect, profile as prof, report, rules
from .model import AuditResult

VERSION = "0.2.0"
ROOT = Path(__file__).resolve().parent.parent
DATA = Path(__file__).resolve().parent / "data"
DEFAULT_CHECKS = DATA / "checks"
CORPUS = DATA / "architecture.json"


def layer_names() -> dict[int, str]:
    try:
        data = json.loads(CORPUS.read_text(encoding="utf-8"))
        return {int(l["id"]): l["name"] for l in data.get("LAYERS", [])}
    except (OSError, ValueError, KeyError):
        return {}


def _ingest(target: str) -> tuple[Path, tempfile.TemporaryDirectory | None]:
    if target.startswith("http://") or target.startswith("https://"):
        tmp = tempfile.TemporaryDirectory(prefix="aivitals-")
        ok = True
        try:
            import subprocess
            subprocess.run(["git", "clone", "--depth", "1", target, f"{tmp.name}/repo"],
                           check=True, capture_output=True, timeout=180)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            ok = False
            raise SystemExit(f"clone 失败：{e}\n提示：可先本地 clone，再用路径扫描。")
        finally:
            if not ok:
                tmp.cleanup()
        return Path(tmp.name) / "repo", tmp
    p = Path(target).expanduser()
    if not p.exists():
        raise SystemExit(f"路径不存在：{p}")
    return p, None


def cmd_scan(args: argparse.Namespace) -> int:
    root, tmp = _ingest(args.target)
    try:
        checks, errs = rules.load(Path(args.checks))
        if errs:
            for e in errs:
                print(f"[rules] {e}", file=sys.stderr)
        if not checks:
            raise SystemExit("没有可用规则")
        profile, files = prof.build(root, rules.languages_covered(checks))
        if args.maturity:
            profile.maturity = args.maturity
        result = detect.run_checks(profile, files, checks, layer_names())

        claim_results, claim_docs, claim_pairs = [], [], []
        if args.doc:
            preds, perrs = claims_mod.load_predicates(Path(args.predicates))
            for e in perrs:
                print(f"[claims] {e}", file=sys.stderr)
            for raw in args.doc:
                p = Path(raw) if Path(raw).is_absolute() else root / raw
                if p.exists():
                    claim_docs.append(p)
                    rs = claims_mod.run(root, p, files, profile, preds)
                    claim_results.extend(rs)
                    claim_pairs.append((p, rs))
                else:
                    print(f"[claims skip] 文档不存在：{p}", file=sys.stderr)

        baseline_note = ""
        if args.baseline:
            bp = Path(args.baseline).expanduser()

            def _fp(f):
                ev = f.evidence[0] if f.evidence else None
                return f"{f.check_id}|{ev.file if ev else ''}|{ev.line if ev else 0}"

            fps = {_fp(f) for f in result.findings}
            if args.update_baseline:
                bp.parent.mkdir(parents=True, exist_ok=True)
                bp.write_text(json.dumps({"version": 1, "fingerprints": sorted(fps)},
                                         ensure_ascii=False, indent=1), encoding="utf-8")
                baseline_note = f"基线已写入 {bp}（{len(fps)} 条）"
            else:
                known = set()
                if bp.exists():
                    known = set(json.loads(bp.read_text(encoding="utf-8")).get("fingerprints", []))
                kept = [f for f in result.findings if _fp(f) not in known]
                result.suppressed = [f for f in result.findings if _fp(f) in known]
                suppressed = len(result.suppressed)
                result.findings = kept
                baseline_note = f"基线抑制 {suppressed} 条既有问题（仅报新增）"

        outdir = Path(args.out).expanduser()
        outdir.mkdir(parents=True, exist_ok=True)
        formats = [f.strip().lower() for f in args.format.split(",") if f.strip()]
        written = []
        if "json" in formats:
            p = outdir / "report.json"
            data = report.to_json(result)
            if claim_pairs:
                data["claims"] = {
                    "documents": [str(d) for d, _ in claim_pairs],
                    "results": [r.to_dict() for _, rs in claim_pairs for r in rs],
                    "disclaimer": "未找到证据不等于没有实现；矛盾仅表示当前代码与声明不一致。",
                }
            p.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
            written.append(p)
        if "md" in formats or "markdown" in formats:
            p = outdir / "report.md"
            md = report.to_markdown(result)
            if claim_pairs:
                md += "\n\n## 声明对正\n\n" + "\n\n".join(
                    claims_mod.to_markdown(rs, d) for d, rs in claim_pairs)
            p.write_text(md, encoding="utf-8")
            written.append(p)
        if "sarif" in formats:
            p = outdir / "report.sarif"
            p.write_text(json.dumps(report.to_sarif(result), ensure_ascii=False, indent=1), encoding="utf-8")
            written.append(p)
        if "html" in formats:
            p = outdir / "report.html"
            p.write_text(report.to_html(result), encoding="utf-8")
            written.append(p)

        s = report.summary(result)
        print(f"AIVitals · {profile.root}")
        print(f"  类型 {profile.repo_type} / 档位 {profile.maturity} / {profile.file_count} 文件 / {profile.loc} 行")
        print(f"  P0 {s['p0']} · P1 {s['p1']} · 已检查 {s['layers_checked']}/17 层 · 总体 {s['overall']}")
        for f in result.findings[:5]:
            print(f"  [{f.severity}] {f.title}  ({f.check_id})")
        if len(result.findings) > 5:
            print(f"  … 另有 {len(result.findings) - 5} 条")
        print("  输出：" + ", ".join(str(p) for p in written))

        if args.fail_on:
            order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
            threshold = order[args.fail_on]
            hits = [f for f in result.findings if order[f.severity] <= threshold]
            return 2 if args.fail_on == "P0" and hits else (1 if hits else 0)
        return 0
    finally:
        if tmp is not None:
            if args.keep_clone:
                print(f"[clone 保留] {root}", file=sys.stderr)
                tmp.cleanup = lambda: None  # type: ignore[method-assign]
            else:
                tmp.cleanup()


def cmd_claims(args: argparse.Namespace) -> int:
    root = Path(args.target).expanduser()
    if not root.exists():
        raise SystemExit(f"路径不存在：{root}")
    docs = []
    for raw in args.doc:
        p = Path(raw) if Path(raw).is_absolute() else root / raw
        if p.exists():
            docs.append(p)
        else:
            print(f"[skip] 文档不存在：{p}", file=sys.stderr)
    if not docs:
        raise SystemExit("没有可用文档（默认找 README.md）")

    profile, files = prof.build(root)
    preds, perrs = claims_mod.load_predicates(Path(args.predicates))
    for e in perrs:
        print(f"[claims] {e}", file=sys.stderr)
    if not preds:
        raise SystemExit("谓词库为空")

    results = []
    for doc in docs:
        results.extend(claims_mod.run(root, doc, files, profile, preds))

    outdir = Path(args.out).expanduser()
    outdir.mkdir(parents=True, exist_ok=True)
    body = "\n".join(claims_mod.to_markdown([r for r in results], d) for d in docs)
    (outdir / "claims.md").write_text("# 声明校验报告\n\n" + body, encoding="utf-8")
    (outdir / "claims.json").write_text(json.dumps({
        "documents": [str(d) for d in docs],
        "results": [r.to_dict() for r in results],
        "disclaimer": "未找到证据不等于没有实现；矛盾仅表示当前代码与声明不一致。",
    }, ensure_ascii=False, indent=1), encoding="utf-8")

    counts = {v: sum(1 for r in results if r.verdict == v) for v in claims_mod.VERDICTS}
    print(f"AIVitals claims · {root}")
    print(f"  文档 {len(docs)} 份 · 声明 {len(results)} 条 · 矛盾 {counts['contradicted']} · 部分 {counts['partial']} · 已证实 {counts['confirmed']} · 未证 {counts['unsupported']}")
    for r in results:
        print(f"  [{r.verdict:<12}] {r.claim.text[:46]}")
    print(f"  输出：{outdir/'claims.md'}, {outdir/'claims.json'}")
    return 2 if counts["contradicted"] else 0


def cmd_checks(args: argparse.Namespace) -> int:
    checks, errs = rules.load(Path(args.checks))
    for e in errs:
        print(f"[err] {e}", file=sys.stderr)
    print(f"{len(checks)} 条规则")
    for c in checks:
        print(f"  {c.id:<14} L{c.layer:<2} {c.severity:<2} {c.kind:<16} gate={c.maturity_gate:<11} {c.title}")
    return 1 if errs else 0


def cmd_eval(args: argparse.Namespace) -> int:
    fixtures = Path(args.fixtures)
    cases = sorted(p for p in fixtures.iterdir() if (p / "expected.json").exists())
    if not cases:
        raise SystemExit(f"没有找到带 expected.json 的样例：{fixtures}")
    checks, errs = rules.load(Path(args.checks))
    if errs:
        for e in errs:
            print(f"[rules] {e}", file=sys.stderr)
    rows = []
    total_expect = total_hit = total_forbid = total_fp = 0
    for case in cases:
        exp = json.loads((case / "expected.json").read_text(encoding="utf-8"))
        profile, files = prof.build(case, rules.languages_covered(checks))
        result = detect.run_checks(profile, files, checks, layer_names())
        got = {f.check_id for f in result.findings}
        expect = set(exp.get("expect", []))
        forbid = set(exp.get("forbid", []))
        hit = len(expect & got)
        fp = len(forbid & got)
        total_expect += len(expect)
        total_hit += hit
        total_forbid += len(forbid)
        total_fp += fp
        recall = hit / len(expect) if expect else 1.0
        rows.append((case.name, len(expect), hit, recall, fp, exp.get("maturity"), profile.maturity))
        if args.verbose:
            miss = sorted(expect - got)
            if miss:
                print(f"  {case.name} 漏报: {miss}")
    print(f"{'样例':<28}{'期望':>5}{'命中':>5}{'召回':>8}{'误报':>6}{'档位(期望/实际)':>18}")
    for name, ne, nh, rc, fp, em, am in rows:
        print(f"{name:<28}{ne:>5}{nh:>5}{rc:>8.2f}{fp:>6}{str(em)+'/'+str(am):>18}")
    recall = total_hit / total_expect if total_expect else 1.0
    print(f"\n汇总 recall={recall:.3f}  false_positive={total_fp}（对照 {total_forbid} 条禁止项）")
    ok = recall >= args.min_recall and total_fp == 0
    print("门禁：" + ("PASS" if ok else "FAIL") + f"（recall≥{args.min_recall} 且 误报=0）")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aivitals", description="AI 项目架构体征检查（本地运行，代码不外出）")
    p.add_argument("--version", action="version", version=f"aivitals {VERSION}")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scan", help="扫描一个仓库")
    s.add_argument("target", help="本地路径或 GitHub URL")
    s.add_argument("--checks", default=str(DEFAULT_CHECKS), help="规则目录")
    s.add_argument("--maturity", choices=["prototype", "internal", "production", "multi_tenant"], help="覆盖档位判定")
    s.add_argument("--format", default="md,json,sarif", help="md,json,sarif,html")
    s.add_argument("--out", default="./aivitals-report", help="输出目录")
    s.add_argument("--fail-on", choices=["P0", "P1", "P2", "P3"], help="达到该级别返回非零退出码")
    s.add_argument("--keep-clone", action="store_true", help="保留临时 clone（调试用）")
    s.add_argument("--doc", action="append", default=None, help="同时校验声明：相对仓库的文档路径，可多次")
    s.add_argument("--predicates", default=str(DATA / "claims" / "predicates.yaml"))
    s.add_argument("--baseline", help="基线文件：只报基线之外的新增问题")
    s.add_argument("--update-baseline", action="store_true", help="把当前问题写成基线")
    s.set_defaults(func=cmd_scan)

    cl = sub.add_parser("claims", help="校验文档声明与代码是否一致")
    cl.add_argument("target", help="仓库路径")
    cl.add_argument("--doc", action="append", default=None, help="相对仓库的文档路径，可多次；默认 README.md")
    cl.add_argument("--predicates", default=str(DATA / "claims" / "predicates.yaml"))
    cl.add_argument("--out", default="./aivitals-report")
    cl.set_defaults(func=cmd_claims, doc=["README.md"] if True else [])

    c = sub.add_parser("checks", help="列出规则")
    c.add_argument("--checks", default=str(DEFAULT_CHECKS))
    c.set_defaults(func=cmd_checks)

    e = sub.add_parser("eval", help="用标注样例评测规则")
    e.add_argument("--fixtures", default=str(ROOT / "fixtures"))
    e.add_argument("--checks", default=str(DEFAULT_CHECKS))
    e.add_argument("--min-recall", type=float, default=0.8)
    e.add_argument("--verbose", action="store_true")
    e.set_defaults(func=cmd_eval)

    m = sub.add_parser("mcp", help="以 MCP Server 方式运行（stdio）")
    m.add_argument("--checks", default=str(DEFAULT_CHECKS))
    m.set_defaults(func=cmd_mcp)

    ing = sub.add_parser("ingest", help="把资料抽成候选规则（人工晋升后才生效）")
    ing.add_argument("--source", required=True, help="md / txt / html / docx / pdf 文件")
    ing.add_argument("--id", required=True, help="语料 id，如 geo-2026")
    ing.add_argument("--draft-dir", default=str(DEFAULT_CHECKS / "_draft"), help="候选输出目录")
    ing.add_argument("--no-source", action="store_true", help="只出候选，不存原文")
    ing.set_defaults(func=cmd_ingest)
    return p


def cmd_ingest(args: argparse.Namespace) -> int:
    from . import ingest as ingest_mod
    source = Path(args.source).expanduser()
    if not source.exists():
        raise SystemExit(f"资料不存在：{source}")
    info = ingest_mod.ingest(source, args.id, ROOT, Path(args.draft_dir).expanduser(),
                              keep_source=not args.no_source)
    print(f"AIVitals ingest · {args.id}")
    print(f"  {info['chars']} 字 · {info['sections']} 节 · {info['candidates']} 条候选")
    if info["by_layer"]:
        layers = " · ".join(f"L{k}:{v}" for k, v in info["by_layer"].items() if k)
        print(f"  层分布：{layers or '未识别'}")
    print(f"  候选：{info['draft']}")
    if info["source_dir"]:
        print(f"  原文：{info['source_dir']}（私有，未进公开仓库）")
    print("  下一步：挑候选 → 补 detect/impact/fix/derived_from → 加 fixture → aivitals eval")
    return 0


def cmd_mcp(args: argparse.Namespace) -> int:
    from .mcp_server import serve
    return serve(Path(args.checks))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
